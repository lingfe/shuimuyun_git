/*
SQLyog Ultimate v10.00 Beta1
MySQL - 5.5.40 : Database - yyfdatabase
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`yyfdatabase` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `yyfdatabase`;

/*Table structure for table `userentity` */

DROP TABLE IF EXISTS `userentity`;

CREATE TABLE `userentity` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(20) DEFAULT NULL,
  `upass` varchar(20) DEFAULT NULL,
  `phone` varchar(23) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

/*Data for the table `userentity` */

insert  into `userentity`(`uid`,`uname`,`upass`,`phone`) values (1,'yangjie','123456','18978675645'),(2,'ddd','123456','18722212222'),(3,'lijie','123456','17687459321'),(4,'yannge','121212','15678909876'),(5,'yangjie','121212','15643134141'),(6,'15823914401','yangjie','15823914401');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
