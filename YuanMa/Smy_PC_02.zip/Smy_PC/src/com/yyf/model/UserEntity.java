package com.yyf.model;

/**
  * 文件名：UserEntity.java
  * 描述： 用户登录 注册实体
  * 修改人： 杨杰
  * 修改时间：2017年5月16日 下午7:02:00
  * 修改内容：
 */
public class UserEntity {
	
	private Integer uid;// 用户id
	
	private String uname;// 用户名
	
	private String upass;// 密码
	
	private String phone;// 电话

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getUpass() {
		return upass;
	}

	public void setUpass(String upass) {
		this.upass = upass;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	

	public UserEntity() {
		super();
	}
	/**
	 * @param uid 用户id 
	 * @param uname 用户名
	 * @param upass 密码
	 * @param phone 电话
	 */
	public UserEntity(Integer uid, String uname, String upass, String phone) {
		super();
		this.uid = uid;
		this.uname = uname;
		this.upass = upass;
		this.phone = phone;
		
	}

	/**
	 * ToString() 测试方法
	 * 一句话 方法的功能描述
	 * @author 杨杰     
	 * @created 2017年5月16日 下午7:04:50  
	 * @return
	 */
	@Override
	public String toString() {
		return "UserEntity [uid=" + uid + ", uname=" + uname + ", upass=" + upass + ", phone=" + phone + "]";
	}

	

}
