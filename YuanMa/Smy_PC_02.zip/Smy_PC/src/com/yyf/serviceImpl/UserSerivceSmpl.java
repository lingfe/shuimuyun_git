package com.yyf.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yyf.mapper.UserMapper;
import com.yyf.model.UserEntity;
import com.yyf.service.UserService;

/**
  * 文件名：UserSerivceSmpl.java
  * 描述： Service 的实现类 ServiceImpl 
  * 修改人： 杨杰
  * 修改时间：2017年5月16日 下午7:07:54
  * 修改内容：
 */
@Service
public class UserSerivceSmpl implements UserService {
	
	//添加依赖注入
	@Autowired
	private UserMapper userMapper;

	/**
	 * @author 杨杰     
	 * @created 2017年5月16日 下午7:09:24  
	 * @param uname UserName
	 * @param upass PASSWORD
	 * @return BACK A PAGE
	 */
	@Override
	public UserEntity login(String uname, String upass) {
		UserEntity login = userMapper.login(uname, upass);
		return login;
	}

	@Override
	public List<UserEntity> quaryUser() {
		List<UserEntity> userList = userMapper.quaryUser();
		return userList;
	}

	@Override
	public int queryCustomerCount() {
		int queryCustomerCount = userMapper.queryCustomerCount();
		if (queryCustomerCount > 0) {
			System.out.println(queryCustomerCount);
			return queryCustomerCount;
		}
		return 0;
	}

	@Override
	public int addUser(UserEntity useEentity) {
		int addUser = userMapper.addUser(useEentity);
		if(addUser>0){
			System.out.println(addUser);
			return addUser;
		}
		return 0;
	}

	@Override
	public UserEntity queryUname(String uname) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserEntity queryPhone(String phone) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserEntity queryCustomerNumber(String uid, String upass) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserEntity queryCustomerPhone(String phone) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserEntity queryCustomerOne(String phone, String upass) {
		// TODO Auto-generated method stub
		return null;
	}

}
